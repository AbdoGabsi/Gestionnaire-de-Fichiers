package filemanagerapp;

import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.List;

public class AffichageFichiersView {

    public static void afficher(List<Fichier> fichiers) {
        Stage stage = new Stage();
        VBox content = new VBox(10);

        if (fichiers.isEmpty()) {
            content.getChildren().add(new Label("Aucun fichier trouvé."));
        } else {
            for (Fichier fichier : fichiers) {
                VBox fichierBox = new VBox(5);
                fichierBox.getChildren().addAll(
                    new Label("Chemin : " + fichier.getChemin()),
                    new Label("Auteur : " + fichier.getAuteur()),
                    new Label("Titre : " + fichier.getTitre()),
                    new Label("Tags : " + fichier.getTags()),
                    new Label("Résumé : " + fichier.getResume()),
                    new Label("Commentaires : " + fichier.getCommentaires()),
                    new Label("--------------------------------------------------")
                );
                content.getChildren().add(fichierBox);
            }
        }

        ScrollPane scrollPane = new ScrollPane(content);
        scrollPane.setFitToWidth(true);

        Scene scene = new Scene(scrollPane, 600, 400);
        stage.setTitle("Liste des fichiers favoris");
        stage.setScene(scene);
        stage.show();
    }
}
