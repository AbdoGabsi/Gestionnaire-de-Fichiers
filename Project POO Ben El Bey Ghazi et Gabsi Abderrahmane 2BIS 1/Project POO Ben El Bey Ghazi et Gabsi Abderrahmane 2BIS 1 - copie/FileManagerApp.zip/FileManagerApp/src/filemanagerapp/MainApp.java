package filemanagerapp;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;

public class MainApp extends Application {

    private FichierDAO fichierDAO;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws SQLException {
        Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "SYSTEM", "12345");
        fichierDAO = new FichierDAO(connection);

        VBox root = new VBox(20);
        root.getChildren().addAll(createAddView(), createSearchView(), createStatsView(), createExportView(), createDisplayView());

        // Wrap the root VBox in a ScrollPane to allow scrolling
        ScrollPane scrollPane = new ScrollPane(root);
        scrollPane.setFitToWidth(true);  // Ensures that the width is adjusted to the ScrollPane's width

        Scene scene = new Scene(scrollPane, 800, 600);
        scene.getStylesheets().add(getClass().getResource("style.css").toExternalForm());

        primaryStage.setTitle("Gestion des fichiers favoris");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private VBox createAddView() {

        VBox layout = new VBox(10);
        TextField cheminField = new TextField();
        TextField auteurField = new TextField();
        TextField titreField = new TextField();
        TextField tagsField = new TextField();
        TextField resumeField = new TextField();
        TextField commentairesField = new TextField();
        Button addButton = new Button("Ajouter");

        addButton.setOnAction(e -> {
            String titre = titreField.getText().trim();
            String tags = tagsField.getText().trim();

            // Vérification des champs obligatoires
            if (titre.isEmpty() || tags.isEmpty()) {
                showAlert("Champs obligatoires", "Veuillez remplir les champs Titre et Tags.");
                return;
            }

            Fichier fichier = new Fichier(
                    cheminField.getText(), auteurField.getText(), titre,
                    tags, resumeField.getText(), commentairesField.getText()
            );

            if (fichierDAO.ajouterFichier(fichier)) {
                showAlert("Succès", "Fichier ajouté.");
            } else {
                showAlert("Erreur", "Échec de l'ajout.");
            }
        });

        layout.getChildren().addAll(
                new Label("Chemin"), cheminField,
                new Label("Auteur"), auteurField,
                new Label("Titre"), titreField,
                new Label("Tags"), tagsField,
                new Label("Résumé"), resumeField,
                new Label("Commentaires"), commentairesField,
                addButton
        );
        return layout;
    }

    private VBox createSearchView() {
        VBox layout = new VBox(10);

        // Création des boutons radio
        ToggleGroup group = new ToggleGroup();
        RadioButton tagRadioButton = new RadioButton("Tag");
        tagRadioButton.setToggleGroup(group);
        tagRadioButton.setSelected(true); // Par défaut, rechercher par tag
        RadioButton titreRadioButton = new RadioButton("Titre");
        titreRadioButton.setToggleGroup(group);
        RadioButton auteurRadioButton = new RadioButton("Auteur");
        auteurRadioButton.setToggleGroup(group);

        TextField searchField = new TextField();
        Button searchButton = new Button("Rechercher");

        searchButton.setOnAction(e -> {
            String searchCriteria = "tags"; // Par défaut, recherche par tag
            if (titreRadioButton.isSelected()) {
                searchCriteria = "titre";
            } else if (auteurRadioButton.isSelected()) {
                searchCriteria = "auteur";
            }

            List<Fichier> fichiers = fichierDAO.rechercherFichiers(searchField.getText(), searchCriteria);
            AffichageFichiersView.afficher(fichiers);
    
        });

        layout.getChildren().addAll(
                new Label("Recherche par :"), tagRadioButton, titreRadioButton, auteurRadioButton,
                new Label("zone de saisie de recherche"), searchField, searchButton
        );
        return layout;
    }

    private VBox createStatsView() {
        VBox layout = new VBox(10);
        Button statsButton = new Button("Afficher les statistiques");

        statsButton.setOnAction(e -> {
            // Obtenir les statistiques
            String stats = fichierDAO.obtenirStatistiques();

            // Afficher les statistiques dans une alerte
            showAlert("Statistiques", stats);
        });

        layout.getChildren().add(statsButton);
        return layout;
    }

    private VBox createExportView() {
    VBox layout = new VBox(10);
    TextField pathField = new TextField();
    pathField.setPromptText("C:/fichiers.txt");

    Button exportButton = new Button("Exporter en TXT");
    exportButton.setOnAction(e -> {
        String path = pathField.getText().trim();
        if (path.isEmpty()) {
            showAlert("Erreur", "Veuillez entrer un chemin de fichier.");
            return;
        }

        boolean result = fichierDAO.exporterTXT(path);
        showAlert("Exportation", result ? "Exportation réussie." : "Erreur lors de l'exportation.");
    });

    layout.getChildren().addAll(
        new Label("Exporter vers fichier texte (.txt)"),
        pathField,
        exportButton
    );
    return layout;
}


    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setContentText(content);
        alert.setHeaderText(null);
        alert.showAndWait();
    }

    private VBox createDisplayView() {
        VBox layout = new VBox(10);
        Button btnAfficher = new Button("Afficher les fichiers");

        btnAfficher.setOnAction(e -> {
            List<Fichier> fichiers = fichierDAO.getAllFichiers();
            AffichageFichiersView.afficher(fichiers);
        });

        layout.getChildren().add(btnAfficher);
        return layout;
    }
}
