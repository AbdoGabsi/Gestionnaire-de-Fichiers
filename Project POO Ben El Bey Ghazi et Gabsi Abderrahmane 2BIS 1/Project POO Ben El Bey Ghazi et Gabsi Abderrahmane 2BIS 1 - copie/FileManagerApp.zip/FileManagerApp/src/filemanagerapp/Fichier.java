/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package filemanagerapp;

public class Fichier {
    private String chemin;
    private String auteur;
    private String titre;
    private String tags;
    private String resume;
    private String commentaires;

    public Fichier(String chemin, String auteur, String titre, String tags, String resume, String commentaires) {
        this.chemin = chemin;
        this.auteur = auteur;
        this.titre = titre;
        this.tags = tags;
        this.resume = resume;
        this.commentaires = commentaires;
    }

    public String getChemin() {
        return chemin;
    }

    public String getAuteur() {
        return auteur;
    }

    public String getTitre() {
        return titre;
    }

    public String getTags() {
        return tags;
    }

    public String getResume() {
        return resume;
    }

    public String getCommentaires() {
        return commentaires;
    }

    @Override
    public String toString() {
        return "Fichier{" +
                "chemin='" + chemin + '\'' +
                ", auteur='" + auteur + '\'' +
                ", titre='" + titre + '\'' +
                ", tags='" + tags + '\'' +
                ", resume='" + resume + '\'' +
                ", commentaires='" + commentaires + '\'' +
                '}';
    }
}
