/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package filemanagerapp;

import java.io.BufferedWriter;
import java.sql.*;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FichierDAO {

    private Connection connection;

    public FichierDAO(Connection connection) {
        this.connection = connection;
    }

    public boolean ajouterFichier(Fichier fichier) {
        String query = "INSERT INTO fichiers_favoris (chemin, auteur, titre, tags, resume, commentaires) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, fichier.getChemin());
            stmt.setString(2, fichier.getAuteur());
            stmt.setString(3, fichier.getTitre());
            stmt.setString(4, fichier.getTags());
            stmt.setString(5, fichier.getResume());
            stmt.setString(6, fichier.getCommentaires());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean mettreAJourFichier(Fichier fichier) {
        String query = "UPDATE fichiers_favoris SET auteur = ?, titre = ?, tags = ?, resume = ?, commentaires = ? WHERE chemin = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, fichier.getAuteur());
            stmt.setString(2, fichier.getTitre());
            stmt.setString(3, fichier.getTags());
            stmt.setString(4, fichier.getResume());
            stmt.setString(5, fichier.getCommentaires());
            stmt.setString(6, fichier.getChemin());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<Fichier> rechercherFichiers(String recherche, String critere) {
        List<Fichier> fichiers = new ArrayList<>();
        String query = "SELECT * FROM fichiers_favoris WHERE " + critere + " LIKE ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            String searchPattern = "%" + recherche + "%";
            stmt.setString(1, searchPattern);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Fichier fichier = new Fichier(
                            rs.getString("chemin"),
                            rs.getString("auteur"),
                            rs.getString("titre"),
                            rs.getString("tags"),
                            rs.getString("resume"),
                            rs.getString("commentaires")
                    );
                    fichiers.add(fichier);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return fichiers;
    }

    public String obtenirStatistiques() {
    // Nombre total de fichiers favoris
    int totalFichiers = getTotalFichiers();
    
    // Liste des auteurs des fichiers favoris
    List<String> auteurs = getAuteursFichiers();
    
    // Liste des tags et le nombre de fichiers associés à chaque tag
    Map<String, Integer> tagCounts = getTagsFichiers();

    StringBuilder stats = new StringBuilder();
    stats.append("Nombre total de fichiers favoris: ").append(totalFichiers).append("\n");
    stats.append("Liste des auteurs des fichiers favoris:\n");
    for (String auteur : auteurs) {
        stats.append("- ").append(auteur).append("\n");
    }
    stats.append("Liste des tags utilisés:\n");
    for (Map.Entry<String, Integer> entry : tagCounts.entrySet()) {
        stats.append("- ").append(entry.getKey()).append(": ").append(entry.getValue()).append(" fichier(s)\n");
    }

    return stats.toString();
}

private int getTotalFichiers() {
    // Exemple de requête pour obtenir le nombre total de fichiers favoris
    String query = "SELECT COUNT(*) FROM fichiers_favoris"; 
    try (PreparedStatement stmt = connection.prepareStatement(query);
         ResultSet rs = stmt.executeQuery()) {
        if (rs.next()) {
            return rs.getInt(1);
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return 0;
}

private List<String> getAuteursFichiers() {
    List<String> auteurs = new ArrayList<>();
    String query = "SELECT DISTINCT auteur FROM fichiers_favoris";
    try (PreparedStatement stmt = connection.prepareStatement(query);
         ResultSet rs = stmt.executeQuery()) {
        while (rs.next()) {
            auteurs.add(rs.getString("auteur"));
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return auteurs;
}

private Map<String, Integer> getTagsFichiers() {
    Map<String, Integer> tagCounts = new HashMap<>();
    String query = "SELECT tags FROM fichiers_favoris";
    try (PreparedStatement stmt = connection.prepareStatement(query);
         ResultSet rs = stmt.executeQuery()) {
        while (rs.next()) {
            String tags = rs.getString("tags");
            List<String> tagList = splitTags(tags); // Utilisation de la fonction splitTags
            for (String tag : tagList) {
                tagCounts.put(tag, tagCounts.getOrDefault(tag, 0) + 1);
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return tagCounts;
}

private List<String> splitTags(String tagsChaine) {
    List<String> tagsList = new ArrayList<>();
    if (tagsChaine != null && !tagsChaine.trim().isEmpty()) {
        String[] splitArray = tagsChaine.split(";");
        for (String tag : splitArray) {
            String cleanedTag = tag.trim();
            if (!cleanedTag.isEmpty()) {
                tagsList.add(cleanedTag);
            }
        }
    }
    return tagsList;
}


    public List<Fichier> getAllFichiers() {
        List<Fichier> fichiers = new ArrayList<>();
        String sql = "SELECT chemin, auteur, titre, tags, resume, commentaires FROM fichiers_favoris"; // adapte le nom de la table si besoin

        try (PreparedStatement statement = connection.prepareStatement(sql); ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                String chemin = resultSet.getString("chemin");
                String auteur = resultSet.getString("auteur");
                String titre = resultSet.getString("titre");
                String tags = resultSet.getString("tags");
                String resume = resultSet.getString("resume");
                String commentaires = resultSet.getString("commentaires");

                Fichier fichier = new Fichier(chemin, auteur, titre, tags, resume, commentaires);
                fichiers.add(fichier);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return fichiers;
    }

    public boolean exporterTXT(String cheminFichier) {
        List<Fichier> fichiers = getAllFichiers(); // Méthode à implémenter si elle n'existe pas
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(cheminFichier))) {
            for (Fichier fichier : fichiers) {
                writer.write("Chemin : " + fichier.getChemin() + "\n");
                writer.write("Auteur : " + fichier.getAuteur() + "\n");
                writer.write("Titre : " + fichier.getTitre() + "\n");
                writer.write("Tags : " + fichier.getTags() + "\n");
                writer.write("Résumé : " + fichier.getResume() + "\n");
                writer.write("Commentaires : " + fichier.getCommentaires() + "\n");
                writer.write("--------------------------------------------------\n");
            }
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

}
